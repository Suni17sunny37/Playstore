package com.wipro.AdminMicroservice.Controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.wipro.AdminMicroservice.Service.UserService;
import com.wipro.AdminMicroservice.dto.ReviewDTO;

@Controller
@RequestMapping("/admin")  // Base path for all admin-related APIs
public class ReviewController {

    @Autowired
    private UserService userService;  // Injecting UserService to handle review-related logic

    /**
     * Get all user reviews
     * Endpoint: GET /admin/reviews
     * @return List of ReviewDTO objects or error message
     */
    @GetMapping("/reviews")
    public ResponseEntity<?> getAllReviews() {
        try {
            List<ReviewDTO> reviews = userService.getAllReviews();
            return ResponseEntity.ok(reviews);  // Return list of reviews with 200 OK
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                                 .body(Map.of("error", "Failed to fetch reviews"));  // Return error message
        }
    }

    /**
     * Delete a specific review by ID
     * Endpoint: DELETE /admin/reviews/{id}
     * @param id - Review ID to delete
     * @return 200 OK on success or 500 error on failure
     */
    @DeleteMapping("/reviews/{id}")
    public ResponseEntity<?> deleteReview(@PathVariable Long id) {
        try {
            userService.deleteReview(id);  // Attempt to delete review
            return ResponseEntity.ok().build();  // Return 200 OK with no body
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                                 .body(Map.of("error", "Failed to delete review"));  // Return error message
        }
    }
}
