package com.wipro.AdminMicroservice.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Data Transfer Object (DTO) for representing the total number of users.
 * This is used to transfer user count data from the User Microservice to the Admin Microservice.
 */
@Getter
@Setter
@AllArgsConstructor  // Generates constructor with all fields
@NoArgsConstructor   // Generates default no-arg constructor
public class UserCountDTO {

    private long count; // Total number of registered users

}
