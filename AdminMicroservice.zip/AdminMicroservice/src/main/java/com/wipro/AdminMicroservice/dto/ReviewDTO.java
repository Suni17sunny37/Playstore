package com.wipro.AdminMicroservice.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Data Transfer Object (DTO) representing a review submitted by a user.
 * Used to transfer review data between the User microservice and Admin microservice.
 */
@Getter
@Setter
@AllArgsConstructor  // Generates constructor with all fields
@NoArgsConstructor   // Generates default no-arg constructor
public class ReviewDTO {
    
    private Long id;          // Unique identifier for the review
    private String userName;  // Name of the user who submitted the review
    private String comment;   // Review comment text
    private int rating;       // Rating given by the user (e.g., 1-5)
}
