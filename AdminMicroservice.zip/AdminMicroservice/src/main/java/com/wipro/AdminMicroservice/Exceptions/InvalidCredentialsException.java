package com.wipro.AdminMicroservice.Exceptions;

/**
 * Custom exception to indicate that the login credentials provided are invalid.
 * 
 * This exception can be thrown during login authentication when the email or password
 * does not match any existing user.
 */
@SuppressWarnings("serial")
public class InvalidCredentialsException extends RuntimeException {

    /**
     * Constructor to create an exception with a specific error message.
     * 
     * @param message The error message explaining the invalid credentials issue.
     */
    public InvalidCredentialsException(String message) {
        super(message);
    }
}
