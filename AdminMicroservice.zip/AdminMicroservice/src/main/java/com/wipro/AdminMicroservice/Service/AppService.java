package com.wipro.AdminMicroservice.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wipro.AdminMicroservice.Exceptions.AppAlreadyExistsException;
import com.wipro.AdminMicroservice.Model.App;
import com.wipro.AdminMicroservice.Repository.AppRepository;

/**
 * Service class that handles all operations related to the App entity.
 */
@Service
public class AppService {

    @Autowired
    private AppRepository appRepository;

    /**
     * Creates a new App record if the name doesn't already exist.
     *
     * @param app the App object to be created
     * @return the saved App object
     * @throws AppAlreadyExistsException if app name already exists
     */
    public App create(App app) throws AppAlreadyExistsException {
        if (appRepository.existsByName(app.getName())) {
            throw new AppAlreadyExistsException("App name already exists!");
        }
        return appRepository.save(app);
    }

    /**
     * Checks if an app with the given name exists.
     *
     * @param appName name of the app
     * @return true if app exists, false otherwise
     */
    public boolean isAppNameExists(String appName) {
        return appRepository.existsByName(appName); 
    }

    /**
     * Retrieves a list of all apps.
     *
     * @return list of apps
     */
    public List<App> getAll() {
        return appRepository.findAll();
    }

    /**
     * Fetches an app by its ID.
     *
     * @param id app ID
     * @return Optional containing the App if found
     */
    public Optional<App> getAppById(int id) {
        return appRepository.findById(id);
    }

    /**
     * Deletes an app by its ID if it exists.
     *
     * @param id app ID
     * @throws RuntimeException if app not found
     */
    public void deleteApp(int id) {
        if (appRepository.existsById(id)) {
            appRepository.deleteById(id);
        } else {
            throw new RuntimeException("App not found");
        }
    }

    /**
     * Retrieves all apps associated with a specific admin ID.
     *
     * @param adminId the ID of the admin
     * @return list of apps
     */
    public List<App> getAppsByAdminId(String adminId) {
        return appRepository.findByAdminId(adminId);
    }

    /**
     * Updates version, name, and description of an app by its ID.
     *
     * @param id app ID
     * @param version new version
     * @param name new name
     * @param description new description
     * @throws RuntimeException if app not found
     */
    public void updateAppDetails(int id, String version, String name, String description) {
        Optional<App> existingApp = appRepository.findById(id);
        if (existingApp.isPresent()) {
            App appToUpdate = existingApp.get();
            appToUpdate.setVersion(version);
            appToUpdate.setName(name);
            appToUpdate.setDescription(description);
            appRepository.save(appToUpdate);
        } else {
            throw new RuntimeException("App not found with ID: " + id);
        }
    }
}
