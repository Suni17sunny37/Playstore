package com.wipro.AdminMicroservice.Model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Represents an Admin entity mapped to the 'admins' table in the database.
 */
@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "admins")
public class Admin {

    // Primary Key for the Admin
    @Id
    private int id;

    // Admin's full name
    private String name;

    // Admin's email 
    private String email;

    // Admin's password
    private String password;
}
