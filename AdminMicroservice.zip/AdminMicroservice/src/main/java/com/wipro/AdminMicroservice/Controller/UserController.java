package com.wipro.AdminMicroservice.Controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.wipro.AdminMicroservice.Service.UserService;

@Controller
@RequestMapping("/admin")  // Base path for all admin-related APIs
public class UserController {

    @Autowired
    private UserService userService;  // Injecting UserService to fetch user-related data

    /**
     * Get total count of users
     * Endpoint: GET /admin/user-count
     * @return A JSON response with key "count" or an error message
     */
    @GetMapping("/user-count")
    public ResponseEntity<?> getUserCount() {
        try {
            long count = userService.getUserCount();  // Call service to fetch user count
            return ResponseEntity.ok().body(Map.of("count", count));  // Return count in response
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE)
                                 .body(Map.of("error", "User service unavailable"));  // Handle service failure
        }
    }
}
