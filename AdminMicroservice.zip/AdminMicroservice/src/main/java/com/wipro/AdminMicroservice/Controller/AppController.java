package com.wipro.AdminMicroservice.Controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.wipro.AdminMicroservice.Model.App;
import com.wipro.AdminMicroservice.Service.AppService;

import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping("/home")
public class AppController {

    @Autowired
    private AppService appService;

    /**
     * Get all apps from the database
     * @return list of all apps
     */
    @GetMapping("/getAllApps")
    public ResponseEntity<List<App>> getAllApps() {
        List<App> apps = appService.getAll();
        return ResponseEntity.ok(apps);
    }

    /**
     * Get a specific app by its ID
     * @param id - app ID
     * @return app if found, else 404
     */
    @GetMapping("/getAppById")
    public ResponseEntity<App> getAppById(@RequestParam int id) {
        Optional<App> app = appService.getAppById(id);
        return app.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    /**
     * Get all apps uploaded by a specific admin
     * @param adminId - admin ID
     * @return list of apps uploaded by the admin
     */
    @GetMapping("/getAppsByAdminId")
    public ResponseEntity<List<App>> getAppsByAdminId(@RequestParam String adminId) {
        List<App> apps = appService.getAppsByAdminId(adminId);
        if (apps.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
        return ResponseEntity.ok(apps);
    }

    /**
     * Delete an app by ID
     * @param id - app ID
     * @return success or error response
     */
    @DeleteMapping("/delete")
    public ResponseEntity<String> deleteApp(@RequestParam int id) {
        try {
            appService.deleteApp(id);
            return ResponseEntity.ok("App deleted successfully");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error deleting app: " + e.getMessage());
        }
    }

    /**
     * Update app details by ID
     * @param id - app ID
     * @param version - new version
     * @param name - new name
     * @param description - new description
     * @return success or error response
     */
    @PostMapping("/update")
    public ResponseEntity<String> updateAppDetails(@RequestParam int id,
                                                   @RequestParam String version,
                                                   @RequestParam String name,
                                                   @RequestParam String description) {
        try {
            Optional<App> existingApp = appService.getAppById(id);
            if (existingApp.isPresent()) {
                appService.updateAppDetails(id, version, name, description);
                return ResponseEntity.ok("App details updated successfully");
            }
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("App not found");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error updating app: " + e.getMessage());
        }
    }

    /**
     * Upload a new app
     * @param name - app name
     * @param description - app description
     * @param version - app version
     * @param category - app category
     * @param session - HTTP session for admin ID
     * @param redirectAttributes - to pass success/error messages
     * @return redirect to /home
     */
    @PostMapping("/upload")
    public String upload(@RequestParam String name,
                         @RequestParam String description,
                         @RequestParam String version,
                         @RequestParam String category,
                         HttpSession session,
                         RedirectAttributes redirectAttributes) {

        // Validate required fields
        if (name.isEmpty() || description.isEmpty() || version.isEmpty() || category.isEmpty()) {
            redirectAttributes.addFlashAttribute("error", "All fields are required.");
            return "redirect:/home";
        }

        // Check for duplicate app name
        if (appService.isAppNameExists(name)) {
            redirectAttributes.addFlashAttribute("error", "App with this name already exists.");
            return "redirect:/home";
        }

        // Validate admin session
        Object adminIdObj = session.getAttribute("adminId");
        if (adminIdObj == null) {
            return "redirect:/login";
        }

        String adminId = adminIdObj.toString();

        try {
            // Create and populate App object
            App app = new App();
            app.setName(name);
            app.setDescription(description);
            app.setVersion(version);
            app.setCategory(category);
            app.setAdminId(adminId);

            // Save the app
            appService.create(app);

            // Success message
            redirectAttributes.addFlashAttribute("success", "App added successfully!");
        } catch (Exception e) {
            // Error message
            redirectAttributes.addFlashAttribute("error", "Error saving app: " + e.getMessage());
        }

        return "redirect:/home"; // Use redirect to prevent form resubmission
    }
}
