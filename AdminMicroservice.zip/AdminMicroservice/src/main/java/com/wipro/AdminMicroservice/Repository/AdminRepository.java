package com.wipro.AdminMicroservice.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.wipro.AdminMicroservice.Model.Admin;

/**
 * Repository interface for Admin entity.
 * Extends JpaRepository to provide CRUD operations and query methods.
 */
@Repository
public interface AdminRepository extends JpaRepository<Admin, Integer> {

    /**
     * Custom finder method to retrieve an Admin by email.
     * 
     * @param email the email of the admin
     * @return the Admin object matching the email
     */
    Admin findByEmail(String email);
}
