package com.wipro.AdminMicroservice.Service;

import java.util.Arrays;
import java.util.List;

import javax.naming.ServiceUnavailableException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.wipro.AdminMicroservice.dto.ReviewDTO;
import com.wipro.AdminMicroservice.dto.UserCountDTO;

@Service
public class UserService {

    // Injecting the user service base URL from application.properties
    @Value("${user.service.url}")
    private String userServiceUrl;

    // Autowiring RestTemplate to make HTTP calls
    @Autowired
    private RestTemplate restTemplate;

    /**
     * Fetches the total count of users from the User Microservice.
     *
     * @return long - number of users
     * @throws ServiceUnavailableException if the user service is unreachable
     */
    public long getUserCount() throws ServiceUnavailableException {
        try {
            String url = userServiceUrl + "/count";
            System.out.println("Attempting to call: " + url); // Logging the request URL

            // Making a GET request to the user service
            ResponseEntity<UserCountDTO> response = restTemplate.getForEntity(
                url,
                UserCountDTO.class
            );

            System.out.println("Response received: " + response.getStatusCode()); // Logging response status

            // Returning the count from the response body
            return response.getBody().getCount();
        } catch (RestClientException e) {
            // Logging the error and throwing a custom exception
            System.err.println("RestTemplate error: " + e.getMessage());
            throw new ServiceUnavailableException("User service unavailable: " + e.getMessage());
        }
    }

    /**
     * Retrieves all reviews from the User Microservice.
     *
     * @return List<ReviewDTO> - list of all reviews
     * @throws ServiceUnavailableException if the user service is unreachable
     */
    public List<ReviewDTO> getAllReviews() throws ServiceUnavailableException {
        try {
            // Making a GET request to fetch all reviews
            ResponseEntity<ReviewDTO[]> response = restTemplate.exchange(
                userServiceUrl + "/reviews/all",
                HttpMethod.GET,
                null,
                ReviewDTO[].class
            );

            // Converting array to list and returning
            return Arrays.asList(response.getBody());
        } catch (RestClientException e) {
            // Throwing custom exception in case of failure
            throw new ServiceUnavailableException("Failed to fetch reviews");
        }
    }

    /**
     * Deletes a review by its ID using the User Microservice.
     *
     * @param reviewId - ID of the review to be deleted
     * @throws ServiceUnavailableException if the delete operation fails
     */
    public void deleteReview(Long reviewId) throws ServiceUnavailableException {
        try {
            // Making a DELETE request to remove the review
            restTemplate.delete(userServiceUrl + "/reviews/" + reviewId);
        } catch (RestClientException e) {
            // Throwing exception if the operation fails
            throw new ServiceUnavailableException("Failed to delete review");
        }
    }
}
