package com.wipro.AdminMicroservice.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.wipro.AdminMicroservice.Model.Admin;
import com.wipro.AdminMicroservice.Service.AdminService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping("/admins")
public class AdminController {

    @Autowired
    private AdminService adminService;

    /**
     * Load the Login Page (GET)
     */
    @GetMapping("/login")
    public String showLoginPage() {
        return "login";
    }

    /**
     * Load the Register Page (GET)
     */
    @GetMapping("/register")
    public String showRegisterPage() {
        return "register";
    }

    /**
     * Register a New Admin (POST)
     * @param fullname - Admin's full name
     * @param email - Admin's email
     * @param password - Admin's password
     */
    @PostMapping("/register")
    public String registerUser(@RequestParam("name") String fullname,
                               @RequestParam("email") String email,
                               @RequestParam("password") String password,
                               HttpServletRequest request) {
        try {
            // Create new Admin object and set values
            Admin newUser = new Admin();
            newUser.setName(fullname);
            newUser.setEmail(email);
            newUser.setPassword(password);

            // Save admin to database
            adminService.registerUser(newUser);

            // Set success message in request scope
            request.setAttribute("message", "Admin registered successfully!");
            return "register";

        } catch (Exception e) {
            // Set error message in request scope
            request.setAttribute("error", "Registration failed. Try again.");
            return "register";
        }
    }

    /**
     * Login Existing Admin (POST)
     * @param email - Admin's email
     * @param password - Admin's password
     * @return home page if successful, else login with error message
     */
    @PostMapping("/login")
    public String loginUser(@RequestParam String email,
                            @RequestParam String password,
                            HttpSession session,
                            Model model) {
        // Find admin by email
        Admin admin = adminService.findByEmail(email);

        // Check if admin exists and password matches
        if (admin == null || !admin.getPassword().equals(password)) {
            model.addAttribute("error", "Invalid email or password.");
            return "login";
        }

        // Store admin ID and name in session
        session.setAttribute("adminId", admin.getId());
        session.setAttribute("adminName", admin.getName());

        return "home";
    }

    /**
     * Logout Admin (POST)
     * @param request - HttpServletRequest to access session
     * @return logout success message
     */
    @PostMapping("/logout")
    public ResponseEntity<String> logout(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session != null) {
            session.invalidate(); // Destroy session
        }
        return ResponseEntity.ok("Logout successful");
    }
}
