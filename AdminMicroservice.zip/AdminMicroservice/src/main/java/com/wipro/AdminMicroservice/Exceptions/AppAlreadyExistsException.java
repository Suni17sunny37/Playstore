package com.wipro.AdminMicroservice.Exceptions;

/**
 * Custom exception thrown when an app with the same name already exists
 * during the upload process.
 */
@SuppressWarnings("serial")
public class AppAlreadyExistsException extends RuntimeException {

    // Constructor that accepts a custom error message
    public AppAlreadyExistsException(String message) {
        super(message);
    }
}
