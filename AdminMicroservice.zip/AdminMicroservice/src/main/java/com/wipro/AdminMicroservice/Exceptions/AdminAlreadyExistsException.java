package com.wipro.AdminMicroservice.Exceptions;

/**
 * Custom exception thrown when an admin with the same email already exists
 * during the registration process.
 */
@SuppressWarnings("serial")
public class AdminAlreadyExistsException extends RuntimeException {

    // Constructor to pass a custom error message
    public AdminAlreadyExistsException(String message) {
        super(message);
    }
}
