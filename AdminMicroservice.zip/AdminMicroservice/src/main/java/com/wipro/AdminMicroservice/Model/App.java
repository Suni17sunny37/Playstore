package com.wipro.AdminMicroservice.Model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Represents an App entity mapped to the 'apps' table in the database.
 */
@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "apps")
public class App {

    // Primary key - unique identifier for each app
    @Id
    private int id;

    // Name of the app
    private String name;

    // Description providing details about the app
    private String description;

    // Version of the app
    private String version;

    // Category the app belongs to 
    private String category;

    // ID of the admin who uploaded or manages the app
    private String adminId;
}
