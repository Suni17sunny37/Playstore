package com.wipro.AdminMicroservice.Exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * Global exception handler for handling exceptions across the entire application.
 * 
 * This class intercepts exceptions thrown from controllers and sends an appropriate
 * error response or redirects to an error page.
 */
@ControllerAdvice
public class GlobalExceptionHandler {

    /**
     * Handles all RuntimeExceptions globally.
     * 
     * @param ex The thrown runtime exception.
     * @param model The model object used to pass data to the view.
     * @return The name of the error view 
     */
    @ExceptionHandler(RuntimeException.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public String handleRuntimeException(RuntimeException ex, Model model) {
        model.addAttribute("errorMessage", ex.getMessage());
        return "error"; // Return a custom error.html or error.jsp view
    }
}
