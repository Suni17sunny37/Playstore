package com.wipro.AdminMicroservice.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.wipro.AdminMicroservice.Service.AppService;

@Controller
@RequestMapping("/home")  // Base URL for all endpoints in this controller
public class HomeController {

    @Autowired
    AppService appService;  // Injecting the AppService to access application-related methods

    // Handles GET request to "/home"
    // This method returns the home view (home.html or home.jsp depending on your template engine)
    @GetMapping
    public String home() {
        return "home";
    }
}
