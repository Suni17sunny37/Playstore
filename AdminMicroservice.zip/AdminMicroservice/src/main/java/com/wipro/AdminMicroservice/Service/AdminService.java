package com.wipro.AdminMicroservice.Service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wipro.AdminMicroservice.Exceptions.AdminAlreadyExistsException;
import com.wipro.AdminMicroservice.Exceptions.InvalidCredentialsException;
import com.wipro.AdminMicroservice.Model.Admin;
import com.wipro.AdminMicroservice.Repository.AdminRepository;

/**
 * Service class for managing Admin-related operations such as registration,
 * login, and data retrieval.
 */
@Service
public class AdminService {

    @Autowired
    private AdminRepository adminRepository;

    /**
     * Registers a new admin.
     * Throws an exception if an admin with the given email already exists.
     *
     * @param admin the admin to register
     * @return the saved Admin object
     */
    public Admin registerUser(Admin admin) {
        if (adminRepository.findByEmail(admin.getEmail()) != null) {
            throw new AdminAlreadyExistsException("Admin with email " + admin.getEmail() + " already exists.");
        }
        return adminRepository.save(admin);
    }

    /**
     * Logs in an admin by verifying email and password.
     * Throws an exception if credentials are invalid.
     *
     * @param email the admin's email
     * @param password the admin's password
     * @return the authenticated Admin object
     */
    public Admin loginUser(String email, String password) {
        Admin admin = adminRepository.findByEmail(email);
        if (admin == null || !admin.getPassword().equals(password)) {
            throw new InvalidCredentialsException("Invalid email or password");
        }
        return admin;
    }

    /**
     * Retrieves an admin based on email.
     *
     * @param email the admin's email
     * @return the Admin object if found, otherwise null
     */
    public Admin findByEmail(String email) {
        return adminRepository.findByEmail(email);
    }
}
