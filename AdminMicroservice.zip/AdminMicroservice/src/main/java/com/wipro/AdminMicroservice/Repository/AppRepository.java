package com.wipro.AdminMicroservice.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.wipro.AdminMicroservice.Model.App;

/**
 * Repository interface for App entity.
 * Provides CRUD operations and custom query methods.
 */
@Repository
public interface AppRepository extends JpaRepository<App, Integer> {

    /**
     * Fetch all apps from the database.
     * @return List of all App entities
     */
    List<App> findAll();

    /**
     * Check if an app with the given name already exists.
     * @param name the name of the app
     * @return true if the app name exists, false otherwise
     */
    boolean existsByName(String name);

    /**
     * Find all apps associated with a specific admin ID.
     * @param adminId the admin's ID
     * @return List of apps created by the specified admin
     */
    List<App> findByAdminId(String adminId);
}
