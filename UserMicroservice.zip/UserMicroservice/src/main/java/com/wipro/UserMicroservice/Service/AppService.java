package com.wipro.UserMicroservice.Service;

import com.wipro.UserMicroservice.Model.AppDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.Collections;
import java.util.List;

/**
 * Service class responsible for communicating with the AdminMicroservice
 * to fetch application data like all apps and app details by ID.
 */
@Service
public class AppService {

    private final RestTemplate restTemplate; // Used to perform HTTP requests
    private final String adminServiceUrl;    // Base URL of the AdminMicroservice

    /**
     * Constructor-based dependency injection for RestTemplate and admin service base URL.
     * 
     * @param restTemplate     the RestTemplate used to make HTTP calls
     * @param adminServiceUrl  the base URL of the AdminMicroservice, defaulting to localhost:8081
     */
    @Autowired
    public AppService(RestTemplate restTemplate, 
                     @Value("${admin.service.url:http://localhost:8081}") String adminServiceUrl) {
        this.restTemplate = restTemplate;
        this.adminServiceUrl = adminServiceUrl;  // Defaults to localhost if not provided externally
    }

    /**
     * Fetches the list of all apps from the AdminMicroservice.
     *
     * @return a List of AppDTO objects; returns an empty list if the call fails
     */
    public List<AppDTO> getAllAppsFromAdmin() {
        try {
            // Construct the endpoint URL
            String url = adminServiceUrl + "/home/getAllApps";

            // Make a GET request to fetch the list of apps using exchange()
            ResponseEntity<List<AppDTO>> response = restTemplate.exchange(
                url,
                HttpMethod.GET,
                null, // No request body required for GET
                new ParameterizedTypeReference<List<AppDTO>>() {}
            );

            // Return response body if present; otherwise return empty list
            return response.getBody() != null ? response.getBody() : Collections.emptyList();

        } catch (Exception e) {
            // Print error if AdminMicroservice is unavailable or request fails
            System.err.println("Error fetching apps: " + e.getMessage());
            return Collections.emptyList(); // Safe fallback to avoid breaking user flow
        }
    }

    /**
     * Retrieves the details of a specific app using its ID by calling the AdminMicroservice.
     *
     * @param appId the ID of the app to be fetched
     * @return the AppDTO object representing app details; returns a default fallback if not found or on failure
     */
    public AppDTO getAppDetails(int appId) {
        try {
            // Construct the endpoint URL with query parameter
            String url = adminServiceUrl + "/home/getAppById?id=" + appId;

            // Make a GET request to retrieve specific app details
            ResponseEntity<AppDTO> response = restTemplate.getForEntity(url, AppDTO.class);

            // Return app details if response is successful and not null
            if (response.getStatusCode().is2xxSuccessful() && response.getBody() != null) {
                return response.getBody();
            }

            // Fallback if response body is null or status is not 200 OK
            return createDefaultAppDTO(appId);

        } catch (Exception e) {
            // Log error and return fallback/default app object
            System.err.println("Error fetching app details: " + e.getMessage());
            return createDefaultAppDTO(appId);
        }
    }

    /**
     * Creates a fallback AppDTO object with default values when actual data is unavailable.
     *
     * @param appId the ID to be included in the fallback object
     * @return a default AppDTO instance with placeholder values
     */
    private AppDTO createDefaultAppDTO(int appId) {
        AppDTO defaultApp = new AppDTO();
        defaultApp.setId(appId);
        defaultApp.setName("Unknown App");
        defaultApp.setDescription("App details not available");
        defaultApp.setVersion("1.0.0");
        defaultApp.setCategory("General");
        return defaultApp;
    }
}
