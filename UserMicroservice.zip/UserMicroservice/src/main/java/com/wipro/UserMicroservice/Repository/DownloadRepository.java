package com.wipro.UserMicroservice.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.wipro.UserMicroservice.Model.Download;
import java.util.List;

/**
 * Repository interface for the Download entity.
 * Extends JpaRepository to provide basic CRUD operations.
 * Contains custom query methods to handle specific download-related queries.
 */
public interface DownloadRepository extends JpaRepository<Download, Integer> {

    /**
     * Fetches all downloads made by a specific user.
     *
     * @param userId the ID of the user
     * @return a list of Download objects for the given user
     */
    List<Download> findByUserId(int userId);

    /**
     * Fetches all downloads for a specific app.
     *
     * @param appId the ID of the app
     * @return a list of Download objects for the given app
     */
    List<Download> findByAppId(int appId);

    /**
     * Checks if a specific user has already downloaded a specific app.
     * Useful for avoiding duplicate downloads and validating before inserting.
     *
     * @param userId the ID of the user
     * @param appId the ID of the app
     * @return true if a download record exists, false otherwise
     */
    boolean existsByUserIdAndAppId(int userId, int appId);

    /**
     * Finds a specific download record by userId and appId.
     * Used for operations like uninstalling (deleting) a specific app for a user.
     *
     * @param userId the ID of the user
     * @param appId the ID of the app
     * @return the Download object if found, or null if not found
     */
    Download findByUserIdAndAppId(int userId, int appId);
}
