package com.wipro.UserMicroservice.Controller;

import com.wipro.UserMicroservice.Exceptions.ReviewNotFoundException;
import com.wipro.UserMicroservice.Model.Review;
import com.wipro.UserMicroservice.Service.Reviewservice;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * REST Controller for handling review-related operations by users.
 */
@RestController
@RequestMapping("/users/reviews") // Base URL for all review-related endpoints
public class ReviewController {

    @Autowired
    private Reviewservice reviewService;

    /**
     * Endpoint to submit a new review.
     * Validates the session to ensure the user is authenticated.
     *
     * @param review The review data from request body
     * @param request HTTP request to extract session
     * @return ResponseEntity with success or error message
     */
    @PostMapping
    public ResponseEntity<Map<String, String>> submitReview(@RequestBody Review review, 
                                         HttpServletRequest request) {
        try {
            // Retrieve session and validate user authentication
            HttpSession session = request.getSession(false);
            if (session == null || session.getAttribute("userId") == null) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body(Map.of("error", "User not authenticated"));
            }

            // Set the userId from session before saving the review
            Integer userId = (Integer) session.getAttribute("userId");
            review.setUserId(userId);
            reviewService.submitReview(review);
            
            return ResponseEntity.ok()
                .body(Map.of("message", "Review submitted successfully"));
        } catch (IllegalArgumentException e) {
            // Handle validation errors
            return ResponseEntity.badRequest()
                .body(Map.of("error", e.getMessage()));
        } catch (Exception e) {
            // Handle any other unexpected exceptions
            return ResponseEntity.internalServerError()
                .body(Map.of("error", "Failed to submit review"));
        }
    }

    /**
     * Endpoint to get all reviews (admin use or testing).
     *
     * @return ResponseEntity with list of all reviews
     */
    @GetMapping("/all")
    public ResponseEntity<List<Review>> getAll(){
        return ResponseEntity.ok(reviewService.getReviews());
    }

    /**
     * Endpoint to fetch reviews for a specific application ID.
     *
     * @param appId The application ID to filter reviews
     * @return ResponseEntity with list of reviews for the given app ID
     */
    @GetMapping
    public ResponseEntity<List<Review>> getReviewsByAppId(@RequestParam int appId) {
        List<Review> reviews = reviewService.getReviewsByAppId(appId);
        return ResponseEntity.ok(reviews);
    }

    /**
     * Endpoint to delete a review by its ID.
     *
     * @param id Review ID to be deleted
     * @return ResponseEntity with success or error message
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteReview(@PathVariable int id) {
        try {
            reviewService.deleteReview(id);
            return ResponseEntity.ok("Review with ID " + id + " deleted successfully");
        } catch (ReviewNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        }
    }
}
