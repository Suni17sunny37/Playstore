package com.wipro.UserMicroservice.Repository;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.wipro.UserMicroservice.Model.User;

/**
 * Repository interface for User entity.
 * Extends JpaRepository to provide CRUD operations on the User table.
 */
@Repository
public interface UserRepository extends JpaRepository<User, Integer> {

    /**
     * Finds a user by their email address.
     * 
     * @param email the email of the user
     * @return the User object if found, otherwise null
     */
    User findByEmail(String email);

    /**
     * Finds a user by their name.
     * 
     * @param username the name of the user
     * @return an Optional containing the User if found, or empty if not
     */
    Optional<User> findByName(String username);
}
