package com.wipro.UserMicroservice.Service;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wipro.UserMicroservice.Exceptions.ReviewNotFoundException;
import com.wipro.UserMicroservice.Model.Review;
import com.wipro.UserMicroservice.Repository.ReviewRepository;

import jakarta.transaction.Transactional;

@Service
public class Reviewservice {

    @Autowired
    private ReviewRepository reviewRepository;

    /**
     * Submit a new review after validating input.
     * Throws IllegalArgumentException if rating is out of range or comment is too long.
     *
     * @param review Review object to be saved
     */
    @Transactional
    public void submitReview(Review review) {
        // Validate rating (1 to 5 only)
        if (review.getRating() < 1 || review.getRating() > 5) {
            throw new IllegalArgumentException("Rating must be between 1 and 5");
        }

        // Validate comment length (max 255 characters)
        if (review.getComment() != null && review.getComment().length() > 255) {
            throw new IllegalArgumentException("Comment must be 255 characters or less");
        }

        // Optional: Print debug logs
        System.out.println("Saving review: " + review);

        // Save the validated review
        Review savedReview = reviewRepository.save(review);
        System.out.println("Review saved with ID: " + savedReview.getId());
    }

    /**
     * Get all reviews for a specific app.
     *
     * @param appId App ID
     * @return list of reviews
     */
    public List<Review> getReviewsByAppId(int appId) {
        return reviewRepository.findByAppId(appId);
    }

    /**
     * Get all reviews in the database.
     *
     * @return list of all reviews
     */
    public List<Review> getReviews() {
        return reviewRepository.findAll();
    }

    /**
     * Deletes a review by its ID.
     * If review doesn't exist, throws ReviewNotFoundException.
     *
     * @param id ID of the review to delete
     */
    public void deleteReview(int id) {
        reviewRepository.findById(id)
            .orElseThrow(() -> new ReviewNotFoundException("Review not found with ID: " + id));
        
        reviewRepository.deleteById(id);
    }
}
