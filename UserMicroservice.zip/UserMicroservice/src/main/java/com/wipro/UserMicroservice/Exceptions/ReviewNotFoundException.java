package com.wipro.UserMicroservice.Exceptions;

/**
 * Custom exception thrown when a requested review is not found.
 * This is typically used in scenarios like deleting or fetching
 * a review by ID that doesn't exist in the database.
 */
@SuppressWarnings("serial")
public class ReviewNotFoundException extends RuntimeException {

    /**
     * Constructor to create the exception with a specific error message.
     *
     * @param message Descriptive message about the exception
     */
    public ReviewNotFoundException(String message) {
        super(message);
    }
}
