package com.wipro.UserMicroservice.Controller;

import com.wipro.UserMicroservice.Model.AppDTO;
import com.wipro.UserMicroservice.Service.AppService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

/**
 * Controller class that handles HTTP requests related to applications.
 */
@Controller
@RequestMapping("/api/apps")
@CrossOrigin(origins = "*") // Enables CORS for all origins
public class AppController {

    @Autowired
    private AppService appService;  // Injecting AppService to handle business logic

    /**
     * Endpoint to retrieve app details by appId.
     * 
     * @param appId ID of the application
     * @return ResponseEntity with app details if found, otherwise 404 Not Found
     */
    @GetMapping("/{appId}")
    public ResponseEntity<AppDTO> getAppDetails(@PathVariable int appId) {
        AppDTO appDetail = appService.getAppDetails(appId);
        if (appDetail != null) {
            return ResponseEntity.ok(appDetail);  // 200 OK with app data
        } else {
            return ResponseEntity.notFound().build();  // 404 Not Found
        }
    }

    /**
     * Endpoint to retrieve all available apps.
     * 
     * @return ResponseEntity with list of apps or 500 Internal Server Error
     */
    @GetMapping
    public ResponseEntity<List<AppDTO>> getAllApps() {
        try {
            List<AppDTO> apps = appService.getAllAppsFromAdmin();
            return ResponseEntity.ok(apps);  // 200 OK with app list
        } catch (Exception e) {
            return ResponseEntity.internalServerError().build();  // 500 Internal Server Error
        }
    }
}
