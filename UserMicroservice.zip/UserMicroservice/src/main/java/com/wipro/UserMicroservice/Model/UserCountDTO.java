package com.wipro.UserMicroservice.Model;

/**
 * A simple Data Transfer Object (DTO) to hold the count of users.
 * This is typically used for sending a lightweight response containing user statistics.
 */
public class UserCountDTO {

    // Stores the total number of users
    private long count;

    /**
     * No-args constructor required for frameworks like Spring.
     */
    public UserCountDTO() {}

    /**
     * Parameterized constructor to easily initialize count.
     * @param count total number of users
     */
    public UserCountDTO(long count) {
        this.count = count;
    }

    /**
     * Getter for user count
     * @return count
     */
    public long getCount() {
        return count;
    }

    /**
     * Setter for user count
     * @param count total number of users
     */
    public void setCount(long count) {
        this.count = count;
    }
}
