package com.wipro.UserMicroservice.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.wipro.UserMicroservice.Model.User;
import com.wipro.UserMicroservice.Model.UserCountDTO;
import com.wipro.UserMicroservice.Service.UserService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

/**
 * Controller class to handle user-related operations like login, registration,
 * logout, and viewing user data.
 */
@Controller
@RequestMapping("/users")
public class UserController {

    @Autowired
    private UserService userService;

    /**
     * Load the login page.
     *
     * @return View name of login page (login.jsp)
     */
    @GetMapping("/login")
    public String showLoginPage() {
        return "login";
    }

    /**
     * Load the registration page.
     *
     * @return View name of registration page (register.jsp)
     */
    @GetMapping("/register")
    public String showRegisterPage() {
        return "register";
    }

    /**
     * Register a new user from the form inputs.
     *
     * @param fullname User's full name
     * @param email User's email
     * @param password User's password
     * @param request HttpServletRequest to set request attributes
     * @return View name for register.jsp with success or error message
     */
    @PostMapping("/register")
    public String registerUser(@RequestParam("name") String fullname,
                               @RequestParam("email") String email,
                               @RequestParam("password") String password,
                               HttpServletRequest request) {
        try {
            User newUser = new User();
            newUser.setName(fullname);
            newUser.setEmail(email);
            newUser.setPassword(password);
            
            userService.registerUser(newUser); // Save user

            request.setAttribute("message", "User registered successfully!");
            return "register";
        } catch (Exception e) {
            request.setAttribute("error", "Registration failed. Try again.");
            return "register";
        }
    }

    /**
     * Login validation for user.
     *
     * @param email Email entered by user
     * @param password Password entered by user
     * @param session HttpSession to store user session
     * @param model Spring Model to pass error message
     * @return View name based on success/failure
     */
    @PostMapping("/login")
    public String loginUser(@RequestParam String email, 
                            @RequestParam String password, 
                            HttpSession session, 
                            Model model) {
        // Check if user exists
        User user = userService.findByEmail(email);

        if (user == null) {
            model.addAttribute("error", "Invalid email or password.");
            return "login";
        }

        // Validate password
        if (!user.getPassword().equals(password)) {
            model.addAttribute("error", "Invalid email or password.");
            return "login";
        }

        // Store user ID in session
        session.setAttribute("userId", user.getId());

        return "home"; // Redirect to home.jsp on success
    }

    /**
     * Log the user out by invalidating the session.
     *
     * @param request HttpServletRequest to access session
     * @return ResponseEntity with logout confirmation
     */
    @PostMapping("/logout")
    public ResponseEntity<String> logout(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session != null) {
            session.invalidate(); // Destroy the session
        }
        return ResponseEntity.ok("Logout successful");
    }

    /**
     * Return list of all users (useful for admin or testing).
     *
     * @return List of users
     */
    @GetMapping("/all")
    public List<User> getAllUsers() {
        return userService.getAllUsers();
    }

    /**
     * Return the count of registered users.
     *
     * @return UserCountDTO containing total number of users
     */
    @GetMapping("/count")
    @ResponseBody
    public UserCountDTO getUserCount() {
        long count = userService.getUserCount();
        return new UserCountDTO(count);
    }
}
