package com.wipro.UserMicroservice.Exceptions;

/**
 * Custom exception thrown when an attempt is made to register a user
 * with an email or identifier that already exists in the system.
 */
@SuppressWarnings("serial")
public class UserAlreadyExistsException extends RuntimeException {

    /**
     * Constructor to initialize the exception with a custom message.
     *
     * @param message Detailed message indicating the cause of the exception
     */
    public UserAlreadyExistsException(String message) {
        super(message);
    }
}
