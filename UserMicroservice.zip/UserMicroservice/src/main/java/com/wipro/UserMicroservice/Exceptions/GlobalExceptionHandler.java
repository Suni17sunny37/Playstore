package com.wipro.UserMicroservice.Exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ControllerAdvice;

/**
 * This class handles exceptions globally across all controllers
 * using the @ControllerAdvice annotation.
 * It provides centralized exception handling and maps custom
 * exceptions to appropriate HTTP status codes and messages.
 */
@ControllerAdvice
public class GlobalExceptionHandler {

    /**
     * Handles cases where a user tries to register with an email that already exists.
     *
     * @param ex the exception thrown when the user already exists
     * @return ResponseEntity with HTTP 409 (Conflict) and the exception message
     */
    @ExceptionHandler(UserAlreadyExistsException.class)
    public ResponseEntity<String> handleUserAlreadyExists(UserAlreadyExistsException ex) {
        return new ResponseEntity<>(ex.getMessage(), HttpStatus.CONFLICT);
    }

    /**
     * Handles cases where user login fails due to invalid credentials.
     *
     * @param ex the exception thrown when credentials are invalid
     * @return ResponseEntity with HTTP 401 (Unauthorized) and the exception message
     */
    @ExceptionHandler(InvalidCredentialsException.class)
    public ResponseEntity<String> handleInvalidCredentials(InvalidCredentialsException ex) {
        return new ResponseEntity<>(ex.getMessage(), HttpStatus.UNAUTHORIZED);
    }
}
