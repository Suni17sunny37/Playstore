package com.wipro.UserMicroservice.Repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.wipro.UserMicroservice.Model.Review;

/**
 * Repository interface for performing CRUD operations on Review entity.
 * Extends JpaRepository to inherit standard JPA methods.
 */
@Repository
public interface ReviewRepository extends JpaRepository<Review, Integer> {

    /**
     * Retrieves a list of reviews associated with a specific application.
     *
     * @param appId the ID of the application
     * @return a list of Review objects for the given app ID
     */
    List<Review> findByAppId(int appId);
}
