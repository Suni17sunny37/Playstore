package com.wipro.UserMicroservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;

/**
 * Main class for the User Microservice Application.
 * This class bootstraps the Spring Boot application.
 */
@SpringBootApplication  // Marks this class as a Spring Boot application entry point
public class UserMicroserviceApplication {

    /**
     * Main method - entry point of the Spring Boot application.
     * @param args command-line arguments
     */
    public static void main(String[] args) {
        SpringApplication.run(UserMicroserviceApplication.class, args); // Start the Spring Boot app
    }

    /**
     * Bean definition for RestTemplate.
     * RestTemplate is used to make HTTP requests to other microservices.
     * @return a new instance of RestTemplate
     */
    @Bean
    public RestTemplate restTemplate() {
        return new RestTemplate();  // Used for synchronous client-side HTTP communication
    }
}
