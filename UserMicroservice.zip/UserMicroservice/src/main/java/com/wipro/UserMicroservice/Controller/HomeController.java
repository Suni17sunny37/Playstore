package com.wipro.UserMicroservice.Controller;

// Importing necessary Spring Framework classes
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * HomeController handles HTTP requests related to the "home" route.
 * It is responsible for directing the user to the home page.
 */
@Controller // Indicates that this class serves as a Spring MVC controller
@RequestMapping("/home") // Maps HTTP requests that start with "/home" to this controller
public class HomeController {

    /**
     * Handles GET requests for "/home".
     * 
     * @return the logical view name "home" which will be resolved to /WEB-INF/views/home.jsp
     */
    @GetMapping // Maps HTTP GET requests to the home() method
    public String home() {
        // Returning the view name "home" (typically resolved by a view resolver)
        return "home";
    }
}
