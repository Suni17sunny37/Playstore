package com.wipro.UserMicroservice.Exceptions;

/**
 * Custom exception to be thrown when user login credentials are invalid.
 * This exception is a subclass of RuntimeException and can be caught globally.
 */
@SuppressWarnings("serial")
public class InvalidCredentialsException extends RuntimeException {

    /**
     * Constructor to create the exception with a specific message.
     *
     * @param message Error message to be displayed or logged
     */
    public InvalidCredentialsException(String message) {
        super(message);
    }
}
