package com.wipro.UserMicroservice.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wipro.UserMicroservice.Model.User;
import com.wipro.UserMicroservice.Repository.UserRepository;
import com.wipro.UserMicroservice.Exceptions.UserAlreadyExistsException;
import com.wipro.UserMicroservice.Exceptions.InvalidCredentialsException;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    /**
     * Registers a new user.
     * Checks if a user with the same email already exists.
     *
     * @param user The user object to be registered
     * @return The saved user object
     * @throws UserAlreadyExistsException if the email is already registered
     */
    public User registerUser(User user) {
        if (userRepository.findByEmail(user.getEmail()) != null) {
            throw new UserAlreadyExistsException("User with email " + user.getEmail() + " already exists.");
        }
        return userRepository.save(user);
    }

    /**
     * Logs in the user using email and password.
     * Validates credentials and throws exception if invalid.
     *
     * @param email    User's email
     * @param password User's password
     * @return The user object if credentials are valid
     * @throws InvalidCredentialsException if email not found or password doesn't match
     */
    public User loginUser(String email, String password) {
        User user = userRepository.findByEmail(email);
        if (user == null || !user.getPassword().equals(password)) {
            throw new InvalidCredentialsException("Invalid email or password");
        }
        return user;
    }

    /**
     * Finds a user by email.
     *
     * @param email Email to search
     * @return User object, or null if not found
     */
    public User findByEmail(String email) {
        return userRepository.findByEmail(email);
    }

    /**
     * Retrieves all users.
     *
     * @return List of all users
     */
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    /**
     * Fetches a user by ID.
     *
     * @param userId User ID
     * @return Optional containing user if found
     */
    public Object getUserById(int userId) {
        return userRepository.findById(userId);
    }

    /**
     * Counts the total number of users.
     *
     * @return number of users
     */
    public long getUserCount() {
        return userRepository.count();
    }
}
