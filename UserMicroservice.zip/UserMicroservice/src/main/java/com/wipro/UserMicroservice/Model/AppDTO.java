package com.wipro.UserMicroservice.Model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Data Transfer Object (DTO) for representing app-related information.
 * Used to transfer data between layers (like service and controller)
 * without exposing the entity directly.
 */
@Getter // Generates getters for all fields
@Setter // Generates setters for all fields
@NoArgsConstructor // Generates a no-argument constructor
@AllArgsConstructor // Generates an all-arguments constructor
public class AppDTO {

    private int id;             // Unique identifier of the app
    private String name;        // Name of the app
    private String description; // Short description of the app
    private String category;    // Category to which the app belongs (e.g., Education, Productivity)
    private String version;     // Current version of the app
}
