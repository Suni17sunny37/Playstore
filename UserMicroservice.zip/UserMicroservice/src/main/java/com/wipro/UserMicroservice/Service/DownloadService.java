package com.wipro.UserMicroservice.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wipro.UserMicroservice.Model.Download;
import com.wipro.UserMicroservice.Repository.DownloadRepository;

import java.util.List;

/**
 * Service class to handle business logic related to downloads.
 */
@Service
public class DownloadService {

    @Autowired
    private DownloadRepository downloadRepository;

    /**
     * Records a download for the given user and app.
     * Checks if the user has already downloaded the app to avoid duplication.
     *
     * @param userId ID of the user
     * @param appId  ID of the app
     * @return success or duplicate message
     */
    public String recordDownload(int userId, int appId) {
        boolean alreadyDownloaded = downloadRepository.existsByUserIdAndAppId(userId, appId);
        if (alreadyDownloaded) {
            return "You have already downloaded this app.";
        }

        Download download = new Download();
        download.setUserId(userId);
        download.setAppId(appId);
        downloadRepository.save(download);

        return "App downloaded successfully!";
    }

    /**
     * Fetches all downloads by a specific user.
     *
     * @param userId ID of the user
     * @return list of downloads
     */
    public List<Download> getDownloadsByUserId(int userId) {
        return downloadRepository.findByUserId(userId);
    }

    /**
     * Fetches all downloads for a specific app.
     *
     * @param appId ID of the app
     * @return list of downloads
     */
    public List<Download> getDownloadsByApp(int appId) {
        return downloadRepository.findByAppId(appId);
    }

    /**
     * Fetches all download records in the system.
     *
     * @return list of all downloads
     */
    public List<Download> getAllDownloads() {
        return downloadRepository.findAll();
    }

    /**
     * Uninstalls an app for a specific user by removing the corresponding
     * download record from the database.
     *
     * @param userId ID of the user
     * @param appId  ID of the app
     * @return true if the uninstall was successful, false if the record was not found
     */
    public boolean uninstallApp(int userId, int appId) {
        Download download = downloadRepository.findByUserIdAndAppId(userId, appId);
        if (download != null) {
            downloadRepository.delete(download);
            return true;
        }
        return false;
    }
}
