package com.wipro.UserMicroservice.Controller;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.wipro.UserMicroservice.Model.AppDTO;
import com.wipro.UserMicroservice.Model.Download;
import com.wipro.UserMicroservice.Service.AppService;
import com.wipro.UserMicroservice.Service.DownloadService;

/**
 * REST controller to manage app download operations.
 */
@RestController
@RequestMapping("/api/apps")
@CrossOrigin(origins = "http://localhost:9191")  // Allow CORS from frontend running on port 9191
public class DownloadController {

    @Autowired
    private DownloadService downloadService;

    @Autowired
    private AppService appService;

    /**
     * Endpoint to record a download action for a given app by a user.
     *
     * @param appId  ID of the app being downloaded
     * @param userId ID of the user performing the download
     * @return Status message indicating success or failure
     */
    @PostMapping("/{appId}/download")
    public String recordDownload(@PathVariable int appId, @RequestParam int userId) {
        return downloadService.recordDownload(userId, appId);
    }

    /**
     * Endpoint to retrieve all downloads made by a specific user.
     *
     * @param userId ID of the user
     * @return List of Download objects associated with the user
     */
    @GetMapping("/user/{userId}")
    public ResponseEntity<List<Download>> getDownloadsByUserId(@PathVariable int userId) {
        List<Download> downloads = downloadService.getDownloadsByUserId(userId);
        return ResponseEntity.ok(downloads);  // Return 200 OK with the list of downloads
    }

    /**
     * Endpoint to retrieve detailed information about apps installed by a specific user.
     *
     * @param userId ID of the user
     * @return List of AppDTO objects representing the installed apps
     */
    @GetMapping("/user/{userId}/installed")
    public ResponseEntity<List<AppDTO>> getInstalledAppDetailsByUser(@PathVariable int userId) {
        List<Download> downloads = downloadService.getDownloadsByUserId(userId);

        // Extract appIds
        List<Integer> appIds = downloads.stream()
                                        .map(Download::getAppId)
                                        .distinct()
                                        .collect(Collectors.toList());

        // Fetch app details for each appId
        List<AppDTO> installedApps = appIds.stream()
                                           .map(appService::getAppDetails)
                                           .collect(Collectors.toList());

        return ResponseEntity.ok(installedApps);
    }

    /**
     * Endpoint to uninstall an app by deleting the corresponding download record.
     *
     * @param appId  ID of the app to be uninstalled
     * @param userId ID of the user uninstalling the app
     * @return Success message if uninstalled, or error if record not found
     */
    @PostMapping("/{appId}/uninstall")
    public ResponseEntity<String> uninstallApp(@PathVariable int appId, @RequestParam int userId) {
        boolean removed = downloadService.uninstallApp(userId, appId);
        if (removed) {
            return ResponseEntity.ok("App uninstalled successfully.");
        } else {
            return ResponseEntity.status(404).body("Download record not found.");
        }
    }
}
