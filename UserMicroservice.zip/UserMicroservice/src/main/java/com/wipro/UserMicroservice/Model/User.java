package com.wipro.UserMicroservice.Model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Entity class representing a User.
 * Maps to the "users" table in the database.
 */
@Entity
@Getter // Lombok - generates getter methods for all fields
@Setter // Lombok - generates setter methods for all fields
@AllArgsConstructor // Lombok - generates constructor with all fields
@NoArgsConstructor  // Lombok - generates no-args constructor
@Table(name = "users") // Maps to "users" table
public class User {

    /**
     * Primary key for the User.
     * Should ideally be auto-generated, consider adding @GeneratedValue.
     */
    @Id
    int id;

    /**
     * Full name of the user.
     */
    String name;

    /**
     * Email address used for login.
     */
    String email;

    /**
     * User's password (should be encrypted in production).
     */
    String password;

    /**
     * Role of the user. Default is "user".
     */
    String role = "user";
}
